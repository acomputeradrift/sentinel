"""Sentinel application package."""

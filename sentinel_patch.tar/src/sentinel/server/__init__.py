"""Sentinel server package."""

